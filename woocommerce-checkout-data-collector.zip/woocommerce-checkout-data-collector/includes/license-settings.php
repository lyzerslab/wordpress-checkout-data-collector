<?php
// Add settings page to the admin menu

add_action('admin_menu', 'cde_add_admin_menu');
function cde_add_admin_menu() {
    add_menu_page(
        __('Checkout Data Export', 'checkout-data-to-excel'),
        __('Checkout Data Export', 'checkout-data-to-excel'),
        'manage_options', // Change this to an appropriate capability
        'checkout-data-export',
        'cde_admin_page',
        'dashicons-download',
        20
    );
    
    // Settings page link
    add_submenu_page(
        'checkout-data-export', // Parent menu slug
        __('Settings', 'checkout-data-to-excel'), // Page title
        __('Settings', 'checkout-data-to-excel'), // Menu title
        'manage_woocommerce', // Change this from 'manage_options' to 'manage_woocommerce' or other appropriate capability
        'cde_settings', // Page slug
        'cde_settings_page' // Callback function to render settings page
    );
}

// Settings page render function
function cde_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }

    ?>
    <div class="wrap">
        <h1><?php _e('Checkout Data to Excel Settings', 'checkout-data-to-excel'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('cde_settings_group'); // Settings group
            do_settings_sections('cde_settings'); // Settings sections
            submit_button();
            ?>
        </form>

        <?php
        // Display any error messages
        settings_errors('cde_license_key');
        ?>
    </div>
    <?php
}

// Register settings
add_action('admin_init', 'cde_register_settings');
function cde_register_settings() {
    register_setting('cde_settings_group', 'cde_license_key', 'cde_license_key_sanitize');
    add_settings_section('cde_settings_section', '', null, 'cde_settings');
    add_settings_field('cde_license_key', __('License Key', 'checkout-data-to-excel'), 'cde_license_key_callback', 'cde_settings', 'cde_settings_section');
}

// Sanitize license key input
function cde_license_key_sanitize($input) {
    return sanitize_text_field($input); // Make sure the input is clean
}

function cde_license_key_callback() {
    $license_key = get_option('cde_license_key', '');
    echo '<input type="text" name="cde_license_key" value="' . esc_attr($license_key) . '" class="regular-text">';
}

// Validate license key with API
function cde_validate_license() {
    $license_key = get_option('cde_license_key');
    if (!$license_key) {
        return false; // No license key provided
    }

    // Your API URL to validate the license key
    $response = wp_remote_post('http://lyzerslab-backend.test/auth/api/plugin-license/license.php', [
        'body' => [
            'license_key' => $license_key
        ]
    ]);

    // Debugging response
    if (is_wp_error($response)) {
        error_log('Error in license validation: ' . $response->get_error_message());
        return false; // API call failed
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    // Debugging validation response
    if ($data) {
        error_log('License validation response: ' . print_r($data, true));
    }

    return isset($data['status']) && $data['status'] === 'valid';
}

// Make sure settings are saved properly
add_action('admin_init', 'cde_check_license_on_init');
function cde_check_license_on_init() {
    // Automatically validate the license key when settings are saved
    if (isset($_POST['cde_license_key'])) {
        $valid = cde_validate_license();
        if (!$valid) {
            add_settings_error('cde_license_key', 'invalid-license', 'Invalid license key. Please check and try again.', 'error');
        } else {
            add_settings_error('cde_license_key', 'valid-license', 'License key is valid.', 'updated');
        }
    }
}
