jQuery(function ($) {
    // Listen for changes in checkout form fields
    $(document.body).on('change', 'input, select, textarea', function () {
        var fieldName = $(this).attr('name');
        var fieldValue = $(this).val();
        console.log('Field Changed:', fieldName, fieldValue); // Debugging line

        if (fieldValue) {
            // Send the checkout form data along with product data
            collectAndSaveCheckoutData();
        } else {
            console.warn('Field value is empty. Skipping save for:', fieldName);
        }
    });

    // Function to collect checkout data and product data
    function collectAndSaveCheckoutData() {
        var checkoutData = {};
        var productData = [];

        // Collect the form fields (checkout data)
        $('form.checkout').find('input, select, textarea').each(function () {
            var fieldName = $(this).attr('name');
            var fieldValue = $(this).val();
            if (fieldName) {
                checkoutData[fieldName] = fieldValue;
            }
        });

        // Collect product data (from the cart)
        var products = [];
        $('table.cart').find('tr').each(function () {
            var productName = $(this).find('.product-name').text().trim();
            var productQuantity = $(this).find('.qty').val();
            var productPrice = $(this).find('.product-total').text().trim();
            var productSKU = $(this).data('product-sku'); // Assuming SKU is stored in data attribute

            if (productName && productQuantity && productPrice) {
                products.push({
                    name: productName,
                    quantity: productQuantity,
                    price: productPrice,
                    sku: productSKU
                });
            }
        });

        // Send the data via AJAX
        $.post(cde_ajax_object.ajax_url, {
            action: 'save_checkout_data',
            nonce: cde_ajax_object.nonce,
            checkout_data: JSON.stringify(checkoutData),
            product_data: JSON.stringify(products),
        })
        .done(function (response) {
            if (response.success) {
                console.log('Checkout and product data saved successfully:', response.data);
            } else {
                console.error('Error: Failed to save data. Server Response:', response.data);
            }
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('AJAX request failed:', textStatus, errorThrown);
            console.error('Response Text:', jqXHR.responseText);
        });
    }
});