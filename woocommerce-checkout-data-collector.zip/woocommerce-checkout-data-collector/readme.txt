=== Checkout Data to Excel ===
Contributors: Ziaul Kabir
Tags: checkout, excel, export, ajax
Requires at least: 5.0
Tested up to: 6.3
Stable tag: 1.0
License: GPLv2 or later

This plugin captures checkout data dynamically and saves it in an Excel file for download.

== Installation ==
1. Upload the plugin folder to `/wp-content/plugins/`.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Use the admin panel to download the Excel file of collected data.

== Changelog ==
= 1.0 =
* Initial release.