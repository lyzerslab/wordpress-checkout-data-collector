<?php
/**
 * Plugin Name: Checkout Data to Excel
 * Plugin URI: https://lyzerslab/wordpress-products/checkout-data-to-excel/
 * Description: Capture WooCommerce checkout data and allow downloading it as an Excel sheet from the admin panel.
 * Version: 1.2
 * Author: Lyzerslab
 * Author URI: https://lyzerslab/
 * Text Domain: checkout-data-to-excel
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.3
 * Requires PHP: 7.4
 * WC tested up to: 7.5
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Start PHP session if not already started
if (!session_id()) {
    session_start();
}

// Add settings page to the admin menu
add_action('admin_menu', 'cde_add_settings_menu');
add_action('admin_menu', 'cde_add_admin_menu');

function cde_add_settings_menu() {
    // Main menu page
    add_menu_page(
        __('Checkout Data Export', 'checkout-data-to-excel'),
        __('Checkout Data Export', 'checkout-data-to-excel'),
        'manage_options', // Requires 'manage_options' capability
        'checkout-data-export',
        'cde_admin_page', // Callback for main page
        'dashicons-download',
        20
    );

    // Settings submenu
    add_submenu_page(
        'checkout-data-export', // Parent menu slug
        __('Settings', 'checkout-data-to-excel'),
        __('Settings', 'checkout-data-to-excel'),
        'manage_options', // Capability required
        'cde_settings', // Page slug
        'cde_settings_page' // Callback for settings page
    );
}

// Render the settings page (license key form)
function cde_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Checkout Data to Excel Settings', 'checkout-data-to-excel'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('cde_settings_group'); // Settings group
            do_settings_sections('cde_settings'); // Settings sections
            submit_button();
            ?>
        </form>

        <?php
        // Display any error messages related to license key
        settings_errors('cde_license_key');
        ?>
    </div>
    <?php
}

// Register settings and license key field
add_action('admin_init', 'cde_register_settings');

function cde_register_settings() {
    // Register the license key option
    register_setting('cde_settings_group', 'cde_license_key', 'cde_license_key_sanitize');
    
    // Add section for settings
    add_settings_section('cde_settings_section', '', null, 'cde_settings');
    
    // Add field for the license key
    add_settings_field('cde_license_key', __('License Key', 'checkout-data-to-excel'), 'cde_license_key_callback', 'cde_settings', 'cde_settings_section');
}

// Sanitize the license key input
function cde_license_key_sanitize($input) {
    return sanitize_text_field($input); // Clean the input before saving
}

// Callback for the license key input field
function cde_license_key_callback() {
    $license_key = get_option('cde_license_key', '');
    echo '<input type="text" name="cde_license_key" value="' . esc_attr($license_key) . '" class="regular-text">';
}

// Validate license key with API (disabled for now to allow access)
function cde_validate_license($license_key) {
    // Debugging: Log the license key for verification
    error_log("Validating license: " . $license_key);

    // Ensure the license key is not empty
    if (empty($license_key)) {
        return false;
    }

    // Your API URL to validate the license key
    $response = wp_remote_post('http://lyzerslab-backend.test/auth/api/plugin-license/license.php', [
        'body' => ['license_key' => $license_key]
    ]);

    if (is_wp_error($response)) {
        error_log('License validation failed: ' . $response->get_error_message());
        return false; // Network error or API failure
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    // Check if the response is valid
    if (isset($data['status']) && $data['status'] === 'valid') {
        error_log('License validated successfully!');
        return true;
    } else {
        error_log('License is invalid.');
        return false;
    }
}

// Show the license validation message only on the settings/admin pages
add_action('admin_notices', 'cde_show_license_message');
function cde_show_license_message() {
    $screen = get_current_screen();

    // Check if we're on the plugin settings or admin page
    if (isset($screen->id) && ($screen->id == 'toplevel_page_checkout-data-export' || $screen->id == 'settings_page_cde_settings')) {
        
        $license_key = get_option('cde_license_key', '');
        if (!cde_validate_license($license_key)) {
            // Show message only on the settings page if license is invalid
            echo '<div class="notice notice-error"><p>' . __('You must have a valid license to download the data.', 'checkout-data-to-excel') . '</p></div>';
        } else {
            // If license is valid, show a success message
            echo '<div class="notice notice-success"><p>' . __('Your license is valid!', 'checkout-data-to-excel') . '</p></div>';
        }
    }
}

// Display the settings link next to "Deactivate" on plugin page
function cde_settings_link($links) {
    $settings_link = '<a href="admin.php?page=cde_settings">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'cde_settings_link');

// Add admin page to download Excel
function cde_add_admin_menu() {
    add_menu_page(
        __('Checkout Data Export', 'checkout-data-to-excel'),
        __('Checkout Data Export', 'checkout-data-to-excel'),
        'manage_options',
        'checkout-data-export',
        'cde_admin_page',
        'dashicons-download',
        20
    );
}

// Admin page to download Excel
function cde_admin_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Export Checkout Data to Excel', 'checkout-data-to-excel'); ?></h1>

        <?php
        // Check if the license is valid before showing the download button
        $license_key = get_option('cde_license_key', '');
        if (!cde_validate_license($license_key)) {
            echo '<p>' . __('You must have a valid license to download the data.', 'checkout-data-to-excel') . '</p>';
        } else {
            ?>
            <form method="post" action="">
                <?php wp_nonce_field('cde_download_excel', 'cde_nonce'); ?>
                <p>
                    <button type="submit" name="cde_download_excel" class="button button-primary">
                        <?php _e('Download Excel', 'checkout-data-to-excel'); ?>
                    </button>
                </p>
            </form>
            <?php
        }
        ?>
    </div>
    <?php
}

// Handle Excel download request
add_action('admin_init', 'cde_handle_excel_download');
function cde_handle_excel_download() {
    if (isset($_POST['cde_download_excel']) && check_admin_referer('cde_download_excel', 'cde_nonce')) {
        cde_generate_excel();
    }
}

// Generate and download Excel file
function cde_generate_excel() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkout_data';

    // Fetch both checkout and product data
    $query = "SELECT session_id, field_name, field_value, timestamp FROM $table_name";
    $results = $wpdb->get_results($query);

    if (empty($results)) {
        wp_die(__('No checkout data available to export.', 'checkout-data-to-excel'));
    }

    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Set headers with bold style
    $sheet->setCellValue('A1', 'Session/User ID');
    $sheet->setCellValue('B1', 'Field Name');
    $sheet->setCellValue('C1', 'Field Value');
    $sheet->setCellValue('D1', 'Timestamp');
    
    // Bold headers
    $sheet->getStyle('A1:D1')->getFont()->setBold(true);

    // Auto-size columns
    $sheet->getColumnDimension('A')->setAutoSize(true);
    $sheet->getColumnDimension('B')->setAutoSize(true);
    $sheet->getColumnDimension('C')->setAutoSize(true);
    $sheet->getColumnDimension('D')->setAutoSize(true);

    $current_row = 2;

    foreach ($results as $row) {
        // Decode the field value for better display (json_decode)
        $field_value = json_decode($row->field_value, true);
        
        // Format data for display
        $field_value_str = '';
        if (is_array($field_value)) {
            foreach ($field_value as $key => $value) {
                $field_value_str .= sprintf("%s: %s\n", ucfirst(str_replace('_', ' ', $key)), $value);
            }
        } else {
            $field_value_str = $field_value; // If it's not an array, just display the raw value
        }

        // Fill Excel sheet with data
        $sheet->setCellValue("A$current_row", $row->session_id);
        $sheet->setCellValue("B$current_row", $row->field_name);
        $sheet->setCellValue("C$current_row", $field_value_str);
        $sheet->setCellValue("D$current_row", $row->timestamp);

        $current_row++;
    }

    // Use a unique filename
    $file_name = 'checkout-data-' . date('Y-m-d-H-i-s') . '.xlsx';
    $file_path = plugin_dir_path(__FILE__) . $file_name;

    $writer = new Xlsx($spreadsheet);
    $writer->save($file_path);

    // Serve the file for download
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header("Content-Disposition: attachment; filename=$file_name");
    readfile($file_path);
    unlink($file_path); // Cleanup after serving
    exit;
}